Plus Jakarta Sans goes here as PlusJakartaSans.ttf (variable font, covers all weights).
It was NOT bundled because the sandbox that built this project had no internet.
The Gradle task "downloadFonts" fetches it automatically on your first build (needs internet).
If that fails, download it from fonts.google.com/specimen/Plus+Jakarta+Sans and place it here.
Without it the app falls back to the system font.

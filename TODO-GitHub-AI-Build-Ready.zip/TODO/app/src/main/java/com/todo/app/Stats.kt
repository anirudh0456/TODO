package com.todo.app
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import java.time.*
import java.time.format.DateTimeFormatter

@Composable fun StatsScreen(tasks: List<Task>, vm: TaskVm, back: () -> Unit) {
    val sessions by vm.sessions.collectAsState()
    var n by remember { mutableIntStateOf(7) }; var pick by remember(n) { mutableIntStateOf(n - 1) } // 7 = week, 30 = month; tapped bar
    fun day(ms: Long) = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()
    val perDay = tasks.mapNotNull { it.completedAt }.groupingBy { day(it) }.eachCount() // real completions per day
    val days = List(n) { LocalDate.now().minusDays((n - 1 - it).toLong()) }; val counts = days.map { perDay[it] ?: 0 }; val max = maxOf(1, counts.max())
    val inRange = sessions.filter { day(it.finishedAt) >= days.first() }
    var streak = 0; var d = LocalDate.now(); if (d !in perDay) d = d.minusDays(1); while (d in perDay) { streak++; d = d.minusDays(1) } // days in a row
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { TopBar("Insights", back) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Pill("Week", n == 7) { n = 7 }; Pill("Month", n == 30) { n = 30 } } }
        item { GlassCard(Modifier.fillMaxWidth()) {
            Text("${counts.sum()} completed in $n days", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Row(Modifier.fillMaxWidth().height(140.dp).padding(vertical = 12.dp), Arrangement.spacedBy(if (n > 7) 2.dp else 8.dp), Alignment.Bottom) {
                counts.forEachIndexed { i, c -> val h by animateFloatAsState(maxOf(c / max.toFloat(), .04f), spring(Spring.DampingRatioMediumBouncy), label = "bar")
                    Box(Modifier.weight(1f).fillMaxHeight(h).clip(RoundedCornerShape(6.dp)).background(if (i == pick) Ink.Mint else Ink.Mint.copy(.35f)).clickable { pick = i }) } } // tap a bar
            Text("${days[pick].format(DateTimeFormatter.ofPattern("EEE, MMM d"))}: ${counts[pick]} completed", color = Ink.Muted, fontSize = 13.sp) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassCard(Modifier.weight(1f)) { Text("$streak", fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Day streak", color = Ink.Muted) }
            GlassCard(Modifier.weight(1f)) { Text("${tasks.count { it.done }}", fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Done in total", color = Ink.Muted) } } }
        item { GlassCard(Modifier.fillMaxWidth()) { Text("Focus", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("${inRange.size} sessions • ${inRange.sumOf { it.minutes }} min in $n days", color = Ink.Muted)
            sessions.take(8).forEach { Text(Instant.ofEpochMilli(it.finishedAt).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("MMM d, h:mm a")) + " • ${it.minutes} min", fontSize = 13.sp) }
            if (sessions.isEmpty()) Text("Finish a focus block to see history here.", fontSize = 13.sp, color = Ink.Muted) } }
        if (tasks.any { it.done && it.completedAt == null }) item { Text("Tasks completed before this update have no date, so charts and streaks start from now.", fontSize = 12.sp, color = Ink.Muted) }
    }
}

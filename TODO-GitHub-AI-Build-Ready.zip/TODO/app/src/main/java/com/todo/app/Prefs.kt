package com.todo.app
import android.app.Application
import android.content.Context
import android.os.SystemClock
import androidx.compose.runtime.*
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlin.math.ceil

val Context.store by preferencesDataStore("settings") // small saved-settings file on the phone
val EMPTY_PREFS: Preferences = emptyPreferences() // marker: settings not loaded yet
val K_ONB = intPreferencesKey("onboarded")
val K_THEME = intPreferencesKey("theme"); val K_FOCUS = intPreferencesKey("focus")
val K_SHORT = intPreferencesKey("short"); val K_LONG = intPreferencesKey("long")
fun Preferences.theme() = this[K_THEME] ?: 0 // 0 System, 1 Light, 2 Dark
fun Preferences.focusMin() = this[K_FOCUS] ?: 25
fun Preferences.shortMin() = this[K_SHORT] ?: 5
fun Preferences.longMin() = this[K_LONG] ?: 15

@Stable class AppVm(app: Application) : AndroidViewModel(app) { // reads and writes settings
    private val ds = app.store
    val prefs = ds.data.stateIn(viewModelScope, SharingStarted.Eagerly, EMPTY_PREFS)
    fun set(k: Preferences.Key<Int>, v: Int) { viewModelScope.launch { ds.edit { it[k] = v } } }
}

@Stable class FocusVm : ViewModel() { // the Pomodoro clock; lives on while you switch tabs
    private var lens = listOf(25, 5, 15) // minutes: focus, short break, long break
    var phase by mutableIntStateOf(0) // 0 focus, 1 short break, 2 long break
    var left by mutableIntStateOf(25 * 60) // seconds left
    var running by mutableStateOf(false)
    var sessions by mutableIntStateOf(0) // finished focus blocks
    private var job: Job? = null
    var onSession: (Int) -> Unit = {} // called with minutes when a focus block finishes
    fun sync(l: List<Int>) { val full = left == lens[phase] * 60; lens = l; if (!running && full) left = l[phase] * 60 } // new lengths from Settings
    fun toggle() { // start / pause
        if (running) { job?.cancel(); running = false; return }
        running = true; val end = SystemClock.elapsedRealtime() + left * 1000L // wall-clock end, so the timer stays accurate
        job = viewModelScope.launch {
            while (left > 0) { delay(200); left = ceil((end - SystemClock.elapsedRealtime()) / 1000.0).toInt().coerceAtLeast(0) }
            next(true)
        }
    }
    private fun next(done: Boolean) { // go to the next phase
        job?.cancel(); running = false
        if (phase == 0) { if (done) { sessions++; onSession(lens[0]) }; phase = if (done && sessions % 4 == 0) 2 else 1 } else phase = 0
        left = lens[phase] * 60
    }
    fun skip() = next(false)
    fun reset() { job?.cancel(); running = false; left = lens[phase] * 60 }
}

package com.todo.app
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.*
import androidx.datastore.preferences.core.Preferences
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

val prioNames = listOf("Low", "Medium", "High", "Urgent")
fun dayLabel(d: Long): String { val t = LocalDate.now().toEpochDay() // "Today", "Tomorrow" or "Sat, Nov 21"
    return when (d) { t -> "Today"; t + 1 -> "Tomorrow"; else -> LocalDate.ofEpochDay(d).format(DateTimeFormatter.ofPattern("EEE, MMM d")) } }

@Composable fun Pill(text: String, on: Boolean = false, onClick: (() -> Unit)? = null) { // small rounded chip with a springy press
    val bg by animateColorAsState(if (on) Ink.Text else Ink.Glass, label = "pill")
    val fg by animateColorAsState(if (on) Ink.Canvas else Ink.Text, label = "pillText")
    val src = remember { MutableInteractionSource() }; val pressed by src.collectIsPressedAsState()
    val sc = animateFloatAsState(if (pressed) .94f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "pillPress")
    var m = Modifier.graphicsLayer { scaleX = sc.value; scaleY = sc.value }.clip(CircleShape).background(bg).border(1.dp, Ink.Rim, CircleShape)
    if (onClick != null) m = m.clickable(src, null, onClick = onClick)
    Text(text, m.padding(14.dp, 8.dp), color = fg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
}

@Composable private fun Meta(icon: ImageVector, text: String?) = Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
    Icon(icon, null, Modifier.size(13.dp), Ink.Muted); if (text != null) Text(text, fontSize = 12.sp, color = Ink.Muted) } // small icon + optional label

@Composable fun TaskRow(t: Task, vm: TaskVm, modifier: Modifier = Modifier) { // one task card: check, title, quiet meta line
    val open = LocalOpen.current; val fade = animateFloatAsState(if (t.done) .62f else 1f, label = "rowFade") // finished tasks dim
    val title by animateColorAsState(if (t.done) Ink.Muted.copy(.6f) else Ink.Text, label = "title")
    GlassCard(modifier.graphicsLayer { alpha = fade.value }, onClick = { open(t.id) }, padding = 14.dp, radius = 22.dp, elevation = 4.dp) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Check(t.done) { vm.toggle(t) }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(t.title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, fontFamily = Jakarta, color = title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    textDecoration = if (t.done) TextDecoration.LineThrough else null)
                if (t.priority >= 2 || t.dueDay != null || t.repeatMode > 0 || (t.remindAt != null && !t.done)) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (t.priority >= 2) { val c = if (t.priority == 3) Ink.Danger else Ink.Warn // only High and Urgent are flagged
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Box(Modifier.size(7.dp).clip(CircleShape).background(c)); Text(prioNames[t.priority.coerceIn(0, 3)], fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = c) } }
                    t.dueDay?.let { Meta(Icons.Outlined.CalendarToday, dayLabel(it)) }
                    if (t.repeatMode > 0) Meta(Icons.Outlined.Repeat, null)
                    if (t.remindAt != null && !t.done) Meta(Icons.Outlined.NotificationsNone, null)
                }
            }
            IconButton({ vm.remove(t) }, Modifier.size(32.dp)) { Icon(Icons.Outlined.Close, "Delete", Modifier.size(18.dp), Ink.Muted.copy(.6f)) }
        }
    }
}

@Composable fun TasksScreen(tasks: List<Task>, vm: TaskVm) {
    var q by remember { mutableStateOf("") }; var filter by remember { mutableIntStateOf(0) } // search text; 0 Open, 1 Done, 2 All
    var lf by remember { mutableStateOf<Long?>(null) }; val lists by vm.lists.collectAsState() // list filter
    var text by remember { mutableStateOf("") }; var due by remember { mutableStateOf<Long?>(null) }; var prio by remember { mutableIntStateOf(1) }
    val today = LocalDate.now().toEpochDay()
    val add = { vm.add(text, due, prio, lf); text = ""; due = null; prio = 1 } // save the task, clear the form
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Title("Tasks") }
        item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassCard(Modifier.weight(1f)) { Text("${tasks.count { !it.done }}", fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Open", color = Ink.Muted) }
            GlassCard(Modifier.weight(1f)) { Text("${tasks.count { it.done }}", fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Completed", color = Ink.Muted) } } }
        item { TextField(text, { text = it }, Modifier.fillMaxWidth(), placeholder = { Text("Add new task…") }, singleLine = true, shape = CircleShape,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = KeyboardActions(onDone = { add() }),
            trailingIcon = { IconButton(add) { Icon(Icons.Outlined.Add, "Add", tint = Ink.Mint) } },
            colors = TextFieldDefaults.colors(focusedContainerColor = Ink.Glass, unfocusedContainerColor = Ink.Glass,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Ink.Mint)) }
        item { Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) { // pick a due date
            Pill("No date", due == null) { due = null }; Pill("Today", due == today) { due = today }
            Pill("Tomorrow", due == today + 1) { due = today + 1 }; Pill("Next week", due == today + 7) { due = today + 7 } } }
        item { Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) { // pick a priority
            prioNames.forEachIndexed { i, n -> Pill(n, prio == i) { prio = i } } } }
        item { TextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search tasks…") }, singleLine = true, shape = CircleShape,
            leadingIcon = { Icon(Icons.Outlined.Search, null, tint = Ink.Muted) },
            colors = TextFieldDefaults.colors(focusedContainerColor = Ink.Glass, unfocusedContainerColor = Ink.Glass,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Ink.Mint)) }
        item { Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) { // Done = completed history
            listOf("Open", "Done", "All").forEachIndexed { i, n -> Pill(n, filter == i) { filter = i } } } }
        item { Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) { // custom lists
            Pill("All lists", lf == null) { lf = null }; lists.forEach { l -> Pill(l.name, lf == l.id) { lf = l.id } } } }
        val shown = tasks.filter { (lf == null || it.listId == lf) && (filter == 2 || it.done == (filter == 1)) && it.title.contains(q, ignoreCase = true) }
        items(shown, key = { it.id }, contentType = { "task" }) { TaskRow(it, vm, Modifier.animateItem()) }
    }
}

@Composable fun UpcomingScreen(tasks: List<Task>, vm: TaskVm) {
    val today = LocalDate.now().toEpochDay(); var sel by remember { mutableStateOf<Long?>(null) } // tapped day, or null = all
    val groups = tasks.filter { val d = it.dueDay; d != null && d >= today && (sel == null || d == sel) }.groupBy { it.dueDay!! }.toSortedMap()
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Title("Upcoming"); Text("The days ahead, orchestrated.", color = Ink.Muted) }
        item { Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) { (0..6).forEach { i -> // 7-day strip
            val d = today + i; val date = LocalDate.ofEpochDay(d); val on = sel == d
            val bg by animateColorAsState(if (on) Ink.Text else Ink.Glass, label = "day")
            Column(Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(bg).clickable { sel = if (on) null else d }.padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Text(date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()).uppercase(), fontSize = 10.sp, color = if (on) Ink.Canvas else Ink.Muted)
                Text("${date.dayOfMonth}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = if (on) Ink.Canvas else Ink.Text) } } } }
        if (groups.isEmpty()) item { Text("Nothing scheduled. Give a task a date in Tasks.", color = Ink.Muted) }
        for ((d, list) in groups) {
            item(key = "h$d") { Label(dayLabel(d)) }
            items(list, key = { it.id }, contentType = { "task" }) { TaskRow(it, vm, Modifier.animateItem()) }
        }
    }
}

@Composable fun FocusScreen(tasks: List<Task>, vm: TaskVm, f: FocusVm, p: Preferences) {
    val lens = listOf(p.focusMin(), p.shortMin(), p.longMin()); LaunchedEffect(lens) { f.sync(lens) } // follow Settings
    val prog = 1f - f.left / (lens[f.phase] * 60f); val target = tasks.firstOrNull { !it.done }
    val a by animateFloatAsState(prog, tween(400, easing = LinearEasing), label = "big"); val track = Ink.Line; val mint = Ink.Mint
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        item { Title("Focus") }
        item { GlassCard(Modifier.fillMaxWidth()) {
            Text(listOf("DEEP FOCUS", "SHORT BREAK", "LONG BREAK")[f.phase], fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Ink.Mint)
            Text(target?.title ?: "No open task. Add one in Tasks.", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            if (target != null) Pill("Mark task done") { vm.toggle(target) } } }
        item { Box(Modifier.size(260.dp), Alignment.Center) { // the big timer ring
            Canvas(Modifier.fillMaxSize().padding(10.dp)) { val st = Stroke(14.dp.toPx(), cap = StrokeCap.Round)
                drawArc(track, 0f, 360f, false, style = st)
                drawArc(mint.copy(alpha = .16f), -90f, 360f * a, false, style = Stroke(26.dp.toPx(), cap = StrokeCap.Round)) // soft glow
                drawArc(mint, -90f, 360f * a, false, style = st) }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("%02d:%02d".format(f.left / 60, f.left % 60), fontSize = 56.sp, fontWeight = FontWeight.Bold)
                Text("Interval ${f.sessions % 4 + 1} of 4", color = Ink.Muted, fontSize = 13.sp) } } }
        item { Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp), Alignment.CenterVertically) {
            Button(f::toggle, Modifier.weight(1f).height(56.dp), shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = Ink.Text, contentColor = Ink.Canvas)) {
                Icon(if (f.running) Icons.Outlined.Pause else Icons.Outlined.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text(if (f.running) "Pause" else "Start Focus") }
            IconButton(f::reset) { Icon(Icons.Outlined.Refresh, "Reset", tint = Ink.Muted) } // restart this phase
            IconButton(f::skip) { Icon(Icons.Outlined.SkipNext, "Skip", tint = Ink.Muted) } } } // jump to next phase
    }
}

@Composable fun Stepper(label: String, v: Int, lo: Int, hi: Int, step: Int, onSet: (Int) -> Unit) = Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
    Text(label, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
    IconButton({ onSet((v - step).coerceAtLeast(lo)) }) { Icon(Icons.Outlined.Remove, "Less", tint = Ink.Muted) }
    Text("$v min", Modifier.width(60.dp), textAlign = TextAlign.Center)
    IconButton({ onSet((v + step).coerceAtMost(hi)) }) { Icon(Icons.Outlined.Add, "More", tint = Ink.Mint) }
}

@Composable fun SettingsScreen(app: AppVm, p: Preferences) = LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(12.dp)) {
    item { Title("Settings") }
    item { Label("Appearance") }
    item { GlassCard(Modifier.fillMaxWidth()) { Text("Theme", fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("System", "Light", "Dark").forEachIndexed { i, n -> Pill(n, p.theme() == i) { app.set(K_THEME, i) } } } } }
    item { Label("Focus & timer") }
    item { GlassCard(Modifier.fillMaxWidth()) {
        Stepper("Focus interval", p.focusMin(), 5, 90, 5) { app.set(K_FOCUS, it) }
        Stepper("Short break", p.shortMin(), 1, 30, 1) { app.set(K_SHORT, it) }
        Stepper("Long break", p.longMin(), 5, 45, 5) { app.set(K_LONG, it) } } }
}

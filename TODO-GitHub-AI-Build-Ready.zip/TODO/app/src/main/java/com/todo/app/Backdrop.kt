package com.todo.app
import android.os.Build
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

val LocalBackdrop = compositionLocalOf<GraphicsLayer?> { null } // the recorded screen content, set in TodoApp

/** Real backdrop blur (Android 12+/API 31+): redraws the part of the recorded screen that sits under this surface and blurs it. Older phones skip it. */
fun Modifier.backdropBlur(source: GraphicsLayer?, radius: Dp = 24.dp): Modifier = composed {
    if (source == null || Build.VERSION.SDK_INT < 31) this else {
        val mine = rememberGraphicsLayer(); var pos by remember { mutableStateOf(Offset.Zero) } // where this surface is on screen
        onGloballyPositioned { pos = it.positionInRoot() }.drawBehind {
            mine.renderEffect = BlurEffect(radius.toPx(), radius.toPx(), TileMode.Clamp)
            mine.record { translate(-pos.x, -pos.y) { drawLayer(source) } } // the slice of the screen under me
            drawLayer(mine)
        }
    }
}

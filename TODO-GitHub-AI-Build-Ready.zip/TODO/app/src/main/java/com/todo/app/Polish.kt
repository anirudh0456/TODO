package com.todo.app
import android.content.res.AssetManager
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.*
import kotlinx.coroutines.launch
import java.time.LocalDate

fun loadJakarta(am: AssetManager): FontFamily { // Plus Jakarta Sans from assets/fonts: one variable file, or 4 static files; else system font
    fun has(file: String) = try { am.open("fonts/$file").close(); true } catch (e: Exception) { false }
    val ws = listOf(FontWeight.Normal to "Regular", FontWeight.Medium to "Medium", FontWeight.SemiBold to "SemiBold", FontWeight.Bold to "Bold")
    val list = if (has("PlusJakartaSans.ttf")) ws.map { Font(am, "fonts/PlusJakartaSans.ttf", it.first) } // variable font covers every weight
    else ws.filter { has("PlusJakartaSans-${it.second}.ttf") }.map { Font(am, "fonts/PlusJakartaSans-${it.second}.ttf", it.first) }
    return if (list.isEmpty()) FontFamily.SansSerif else FontFamily(list)
}

fun jakartaTypography(): Typography { // gives every Material text style (including text fields) the same font
    val t = Typography(); val f = Jakarta; fun TextStyle.j() = copy(fontFamily = f)
    return Typography(displayLarge = t.displayLarge.j(), displayMedium = t.displayMedium.j(), displaySmall = t.displaySmall.j(),
        headlineLarge = t.headlineLarge.j(), headlineMedium = t.headlineMedium.j(), headlineSmall = t.headlineSmall.j(),
        titleLarge = t.titleLarge.j(), titleMedium = t.titleMedium.j(), titleSmall = t.titleSmall.j(),
        bodyLarge = t.bodyLarge.j(), bodyMedium = t.bodyMedium.j(), bodySmall = t.bodySmall.j(),
        labelLarge = t.labelLarge.j(), labelMedium = t.labelMedium.j(), labelSmall = t.labelSmall.j())
}

@Composable fun AddFab(onClick: () -> Unit, modifier: Modifier) { // floating mint "+" button with a springy press
    val src = remember { MutableInteractionSource() }; val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) .9f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "fab")
    Box(modifier.size(60.dp).scale(s).shadow(18.dp, CircleShape, ambientColor = Ink.Mint, spotColor = Ink.Mint).clip(CircleShape)
        .background(Brush.linearGradient(listOf(Color(0xFF34D399), Color(0xFF10B981)))).clickable(src, null, onClick = onClick), Alignment.Center) {
        Icon(Icons.Outlined.Add, "New task", Modifier.size(28.dp), Color(0xFF090909)) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun QuickAddSheet(vm: TaskVm, onClose: () -> Unit) { // bottom sheet for adding a task from any main screen
    val st = rememberModalBottomSheetState(skipPartiallyExpanded = true); val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }; var due by remember { mutableStateOf<Long?>(null) }; var prio by remember { mutableIntStateOf(1) }
    val today = LocalDate.now().toEpochDay()
    val close = { scope.launch { st.hide() }.invokeOnCompletion { onClose() }; Unit } // slide down, then remove
    ModalBottomSheet(onDismissRequest = onClose, sheetState = st, containerColor = Ink.Surface, tonalElevation = 0.dp, shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp).navigationBarsPadding().imePadding(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("New task", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            TextField(text, { text = it }, Modifier.fillMaxWidth(), singleLine = true, shape = CircleShape, placeholder = { Text("What needs doing?") },
                colors = TextFieldDefaults.colors(focusedContainerColor = Ink.Glass, unfocusedContainerColor = Ink.Glass,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Ink.Mint))
            Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
                Pill("No date", due == null) { due = null }; Pill("Today", due == today) { due = today }; Pill("Tomorrow", due == today + 1) { due = today + 1 } }
            Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) { prioNames.forEachIndexed { i, n -> Pill(n, prio == i) { prio = i } } }
            Button({ vm.add(text, due, prio); close() }, Modifier.fillMaxWidth().height(52.dp), enabled = text.isNotBlank(), shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = Ink.Text, contentColor = Ink.Canvas)) { Text("Add task", fontWeight = FontWeight.SemiBold) }
        }
    }
}

package com.todo.app
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

val LocalGo = staticCompositionLocalOf<(String) -> Unit> { {} } // "go to this screen" action, set in TodoApp

@Composable fun TopBar(text: String, back: () -> Unit) = Row(verticalAlignment = Alignment.CenterVertically) { // back arrow + title
    IconButton(back) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Ink.Text) }; Title(text) }

@Composable fun DayCell(d: LocalDate, sel: LocalDate, has: Boolean, modifier: Modifier, onPick: (LocalDate) -> Unit) { // one day circle
    val on = d == sel; val today = d == LocalDate.now()
    val bg by animateColorAsState(if (on) Ink.Text else Color.Transparent, label = "cell") // selected = filled
    Column(modifier.aspectRatio(1f).clip(CircleShape).background(bg).then(if (today && !on) Modifier.border(1.5.dp, Ink.Mint, CircleShape) else Modifier) // today = mint ring
        .clickable { onPick(d) }, Arrangement.Center, Alignment.CenterHorizontally) {
        Text("${d.dayOfMonth}", color = if (on) Ink.Canvas else Ink.Text, fontWeight = if (today) FontWeight.Bold else FontWeight.Normal)
        Box(Modifier.size(5.dp).clip(CircleShape).background(if (has) Ink.Mint else Color.Transparent)) } // dot = has tasks
}

@Composable fun CalendarScreen(tasks: List<Task>, vm: TaskVm, back: () -> Unit) {
    var sel by remember { mutableStateOf(LocalDate.now()) }; var weekly by remember { mutableStateOf(false) }; var text by remember { mutableStateOf("") }
    val month = YearMonth.from(sel); val has = tasks.mapNotNull { it.dueDay }.toSet() // days that have tasks
    val start = sel.minusDays((sel.dayOfWeek.value - 1).toLong()) // Monday of the selected week
    val cells: List<LocalDate?> = if (weekly) List(7) { start.plusDays(it.toLong()) } else {
        val all: List<LocalDate?> = List<LocalDate?>(month.atDay(1).dayOfWeek.value - 1) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
        all + List<LocalDate?>((7 - all.size % 7) % 7) { null } } // blanks fill the first and last rows
    fun move(dir: Long) { sel = if (weekly) sel.plusWeeks(dir) else sel.plusMonths(dir) } // prev / next
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().imePadding(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { TopBar("Calendar", back) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Pill("Month", !weekly) { weekly = false }; Pill("Week", weekly) { weekly = true } } }
        item { GlassCard(Modifier.fillMaxWidth()) { Column(Modifier.animateContentSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton({ move(-1) }) { Icon(Icons.Outlined.ChevronLeft, "Previous", tint = Ink.Text) }
                Text(month.month.getDisplayName(TextStyle.FULL, Locale.getDefault()) + " " + month.year, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
                IconButton({ move(1) }) { Icon(Icons.Outlined.ChevronRight, "Next", tint = Ink.Text) } }
            Row { listOf("M", "T", "W", "T", "F", "S", "S").forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 11.sp, color = Ink.Muted) } }
            cells.chunked(7).forEach { week -> Row { week.forEach { d ->
                if (d == null) Spacer(Modifier.weight(1f).aspectRatio(1f)) else DayCell(d, sel, d.toEpochDay() in has, Modifier.weight(1f)) { sel = it } } } } } } }
        item { Label(dayLabel(sel.toEpochDay())) }
        item { TextField(text, { text = it }, Modifier.fillMaxWidth(), singleLine = true, shape = CircleShape, placeholder = { Text("Add a task for this day…") },
            trailingIcon = { IconButton({ vm.add(text, sel.toEpochDay()); text = "" }) { Icon(Icons.Outlined.Add, "Add", tint = Ink.Mint) } },
            colors = TextFieldDefaults.colors(focusedContainerColor = Ink.Glass, unfocusedContainerColor = Ink.Glass,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Ink.Mint)) }
        val day = tasks.filter { it.dueDay == sel.toEpochDay() } // the daily agenda
        if (day.isEmpty()) item { Text("No tasks on this day.", color = Ink.Muted) }
        items(day, key = { it.id }, contentType = { "task" }) { TaskRow(it, vm, Modifier.animateItem()) }
    }
}

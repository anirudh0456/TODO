package com.todo.app
import android.os.Build
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.animation.*
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.*

object Ink { // light = warm ivory + white + deep text; dark = intentional graphite (never pure black), calmer mint
    var dark by mutableStateOf(false) // flipped by TodoApp
    val Canvas: Color get() = if (dark) Color(0xFF171717) else Color(0xFFFAF9F4)
    val Surface: Color get() = if (dark) Color(0xFF1F1F1D) else Color.White // solid sheets and menus
    val Text: Color get() = if (dark) Color(0xFFEDECE7) else Color(0xFF1B1C19)
    val Muted: Color get() = if (dark) Color(0xFFA6A8A1) else Color(0xFF3C4A42).copy(alpha = .78f)
    val Line: Color get() = if (dark) Color(0xFF2E2E2B) else Color(0xFFE8E6DF)
    val Mint: Color get() = if (dark) Color(0xFF34C58E) else Color(0xFF10B981)
    val MintDeep: Color get() = if (dark) Color(0xFF7FE3BC) else Color(0xFF006C49) // small green text
    val Warn: Color get() = if (dark) Color(0xFFE8A93A) else Color(0xFFC77D00) // High priority
    val Danger: Color get() = if (dark) Color(0xFFF0645F) else Color(0xFFD9363E) // Urgent priority
    val Glass: Color get() = if (dark) Color(0xFF222220).copy(alpha = .86f) else Color.White.copy(.78f) // frosted fill
    val Rim: Color get() = if (dark) Color.White.copy(.09f) else Color.White.copy(.9f) // bright edge
}
var Jakarta: FontFamily = FontFamily.SansSerif // replaced at startup by Plus Jakarta Sans when the font files are present

@Composable fun Title(text: String) = Text( // big heading with the mint dot
    buildAnnotatedString { append(text); withStyle(SpanStyle(color = Ink.Mint)) { append(".") } },
    fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Ink.Text, fontFamily = Jakarta, letterSpacing = (-0.9).sp)

private val sheenLight = Brush.verticalGradient(listOf(Color.White.copy(.55f), Color.Transparent), startY = 0f, endY = 180f) // brushes are built once, not every frame
private val sheenDark = Brush.verticalGradient(listOf(Color.White.copy(.06f), Color.Transparent), startY = 0f, endY = 180f)
private val rimLight = Brush.verticalGradient(listOf(Color.White.copy(.9f), Color.White.copy(.27f)))
private val rimDark = Brush.verticalGradient(listOf(Color.White.copy(.10f), Color.White.copy(.03f)))

fun Modifier.glass(shape: Shape, elevation: Dp = 10.dp, backdrop: GraphicsLayer? = null): Modifier { // frosted surface: soft shadow, tint, top sheen, rim that fades downward
    val blur = backdrop != null && Build.VERSION.SDK_INT >= 31
    return this.shadow(elevation, shape, ambientColor = Color.Black.copy(.05f), spotColor = Color.Black.copy(.09f)).clip(shape).backdropBlur(backdrop)
        .background(if (blur) Ink.Glass.copy(alpha = .55f) else Ink.Glass).background(if (Ink.dark) sheenDark else sheenLight) // lighter tint so the blur shows
        .border(1.dp, if (Ink.dark) rimDark else rimLight, shape)
}

@Composable fun GlassCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, padding: Dp = 20.dp, radius: Dp = 26.dp, elevation: Dp = 8.dp, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(radius)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale = animateFloatAsState(if (pressed) .97f else 1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "press") // springy press
    var m = modifier.graphicsLayer { scaleX = scale.value; scaleY = scale.value }.glass(shape, elevation) // read in the draw phase: no recomposition per frame
    if (onClick != null) m = m.clickable(src, null, onClick = onClick)
    Column(m.padding(padding), content = content)
}

@Composable fun Check(done: Boolean, onToggle: () -> Unit) { // round tick box: springy pop, mint glow, check mark scales in
    val fill by animateColorAsState(if (done) Ink.Mint else Color.Transparent, label = "fill")
    val s by animateFloatAsState(if (done) 1f else .92f, spring(Spring.DampingRatioHighBouncy, Spring.StiffnessMedium), label = "pop")
    val glow by animateDpAsState(if (done) 8.dp else 0.dp, label = "glow"); val haptic = LocalHapticFeedback.current
    Box(Modifier.size(26.dp).scale(s).shadow(glow, CircleShape, ambientColor = Ink.Mint, spotColor = Ink.Mint).clip(CircleShape).background(fill)
        .border(2.dp, if (done) Ink.Mint else Ink.Muted.copy(.35f), CircleShape).clickable { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onToggle() }, Alignment.Center) {
        AnimatedVisibility(done, enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn(), exit = scaleOut() + fadeOut()) {
            Icon(Icons.Filled.Check, null, Modifier.size(15.dp), Color.White) }
    }
}

@Composable fun Ring(p: Float, label: String, sub: String) { // progress ring that animates when tasks change
    val a by animateFloatAsState(p, tween(900, easing = FastOutSlowInEasing), label = "ring")
    Box(Modifier.size(84.dp), Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(4.dp)) {
            val st = Stroke(8.dp.toPx(), cap = StrokeCap.Round)
            drawArc(Ink.Line, 0f, 360f, false, style = st) // grey track
            drawArc(Ink.Mint, -90f, 360f * a, false, style = st) // mint progress
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Ink.Text)
            Text(sub, fontSize = 9.sp, color = Ink.Muted, letterSpacing = 1.sp)
        }
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)
private val tabs = listOf( // same 5 tabs as the Stitch design
    Tab("home", "Home", Icons.Outlined.Home), Tab("upcoming", "Upcoming", Icons.Outlined.CalendarMonth),
    Tab("tasks", "Tasks", Icons.Outlined.TaskAlt), Tab("focus", "Focus", Icons.Outlined.Timer), Tab("settings", "Settings", Icons.Outlined.Tune))

@Composable fun GlassNav(current: String?, modifier: Modifier, onPick: (String) -> Unit) { // floating glass pill; the highlight slides with a spring
    val haptic = LocalHapticFeedback.current
    val idx = tabs.indexOfFirst { it.route == current }.coerceAtLeast(0)
    val pos = animateFloatAsState(idx.toFloat(), spring(Spring.DampingRatioLowBouncy, Spring.StiffnessMediumLow), label = "slide")
    BoxWithConstraints(modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp).glass(CircleShape, 16.dp, LocalBackdrop.current).padding(6.dp)) {
        val w = maxWidth / tabs.size
        Box(Modifier.offset { IntOffset((w * pos.value).roundToPx(), 0) }.width(w).height(56.dp).clip(CircleShape).background(Ink.Text.copy(.08f)).border(1.dp, Ink.Rim, CircleShape)) // sliding highlight
        Row { tabs.forEach { t ->
            val on = t.route == current
            val tint by animateColorAsState(if (on) Ink.Text else Ink.Muted, label = "tint")
            val sc by animateFloatAsState(if (on) 1.1f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "icon") // icon bounce
            Column(Modifier.weight(1f).height(56.dp).clip(CircleShape).clickable(remember { MutableInteractionSource() }, null) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onPick(t.route) },
                Arrangement.Center, Alignment.CenterHorizontally) {
                Icon(t.icon, t.label, Modifier.size(22.dp).scale(sc), tint)
                Text(t.label, fontSize = 10.sp, color = tint, fontWeight = FontWeight.SemiBold)
            }
        } }
    }
}

@Composable fun Label(text: String, modifier: Modifier = Modifier) = Text(text.uppercase(), modifier, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp, color = Ink.Muted) // one style for every section label

package com.todo.app
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.*

val pad = PaddingValues(20.dp, 12.dp, 20.dp, 132.dp) // bottom space so the nav bar never covers content

@Composable fun HomeScreen(tasks: List<Task>, vm: TaskVm, onFocus: () -> Unit) {
    val done = tasks.count { it.done }; val total = tasks.size
    val pct = if (total == 0) 0f else done / total.toFloat()
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Pill(java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("EEEE, MMM d"))); Spacer(Modifier.height(8.dp)) // today's date
            val h = java.time.LocalTime.now().hour
            Text((if (h < 12) "Good morning" else if (h < 18) "Good afternoon" else "Good evening") + " ✦", color = Ink.Muted, fontSize = 16.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Title("Home"); Spacer(Modifier.weight(1f))
                Surface(shape = CircleShape, color = Ink.Mint.copy(.1f)) { // "x of y done" chip
                    Text("$done OF $total DONE", Modifier.padding(12.dp, 6.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Ink.MintDeep) }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${(pct * 100).toInt()}% Complete", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink.Text)
                        Text("${total - done} tasks left today", color = Ink.Muted, fontSize = 14.sp)
                    }
                    Ring(pct, "$done/$total", "DONE")
                }
            }
        }
        item { Label("Priority focus") }
        val focus = tasks.filter { !it.done }.take(2) // first two unfinished tasks
        if (focus.isEmpty()) item { Text("Nothing pending. Add a task in Tasks.", color = Ink.Muted) }
        items(focus, key = { it.id }, contentType = { "task" }) { TaskRow(it, vm) }
        item { val go = LocalGo.current; Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { // shortcuts to the extra screens
            listOf("calendar" to "Calendar", "lists" to "Lists", "stats" to "Insights").forEach { (r, n) -> GlassCard(Modifier.weight(1f), onClick = { go(r) }) { Text(n, fontWeight = FontWeight.SemiBold) } } } }
        item { GlassCard(Modifier.fillMaxWidth(), onClick = onFocus) { // jumps to Focus tab
            Text("FOCUS MODE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Ink.MintDeep)
            Text("Start 25m Focus Block", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Ink.Text) } }
    }
}


package com.todo.app
import android.app.*
import android.content.*

object Reminders { // schedules and cancels task reminders
    const val CH = "reminders"
    private fun intent(c: Context, id: Long, title: String = "") = Intent(c, AlarmReceiver::class.java).putExtra("id", id).putExtra("title", title)
    fun set(c: Context, t: Task) { // arm an alarm for this task's reminder time
        cancel(c, t.id); val at = t.remindAt
        if (at == null || t.done || at <= System.currentTimeMillis()) return // nothing to do, or time already passed
        val pi = PendingIntent.getBroadcast(c, t.id.toInt(), intent(c, t.id, t.title), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        c.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) // may fire a few minutes late in Doze
    }
    fun cancel(c: Context, id: Long) { // switch the alarm off
        val pi = PendingIntent.getBroadcast(c, id.toInt(), intent(c, id), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) ?: return
        c.getSystemService(AlarmManager::class.java).cancel(pi); pi.cancel()
    }
}

class AlarmReceiver : BroadcastReceiver() { // runs when an alarm goes off
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(Reminders.CH, "Task reminders", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE) // tap opens the app
        nm.notify(i.getLongExtra("id", 0).toInt(), Notification.Builder(c, Reminders.CH).setSmallIcon(R.drawable.ic_stat_todo).setColor(0xFF10B981.toInt())
            .setContentTitle("TODO").setContentText(i.getStringExtra("title")).setContentIntent(open).setAutoCancel(true).build())
    }
}

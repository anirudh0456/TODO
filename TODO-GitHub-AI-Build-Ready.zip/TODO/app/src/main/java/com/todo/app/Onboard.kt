package com.todo.app
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import kotlinx.coroutines.launch

@Composable fun Onboarding(done: () -> Unit) { // splash + 3 intro pages
    val pages = listOf(
        Triple(Icons.Outlined.TaskAlt, "TODO", "Make Every Day Count."),
        Triple(Icons.Outlined.Add, "Capture everything", "Tasks, notes, subtasks, due dates and reminders in one calm place."),
        Triple(Icons.Outlined.Timer, "Focus deeply", "Pomodoro blocks keep you in flow, and every session is remembered."),
        Triple(Icons.Outlined.BarChart, "See your progress", "Streaks and charts built from what you really complete."))
    val st = rememberPagerState { pages.size }; val scope = rememberCoroutineScope(); val last = st.currentPage == pages.lastIndex
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        HorizontalPager(st, Modifier.weight(1f)) { i -> // swipe between pages
            val s by animateFloatAsState(if (st.currentPage == i) 1f else .85f, spring(Spring.DampingRatioMediumBouncy), label = "page")
            Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                Box(Modifier.size(180.dp).scale(s).glass(CircleShape, 20.dp), Alignment.Center) { Icon(pages[i].first, null, Modifier.size(80.dp), Ink.Mint) }
                Spacer(Modifier.height(32.dp))
                if (i == 0) Title(pages[i].second) else Text(pages[i].second, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp)); Text(pages[i].third, color = Ink.Muted, textAlign = TextAlign.Center, fontSize = 16.sp) } }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { repeat(pages.size) { // page dots
            val w by animateDpAsState(if (st.currentPage == it) 24.dp else 8.dp, label = "dot")
            Box(Modifier.height(8.dp).width(w).clip(CircleShape).background(if (st.currentPage == it) Ink.Mint else Ink.Line)) } }
        Spacer(Modifier.height(24.dp))
        Button({ if (last) done() else scope.launch { st.animateScrollToPage(st.currentPage + 1) } }, Modifier.fillMaxWidth().height(56.dp), shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = Ink.Text, contentColor = Ink.Canvas)) { Text(if (last) "Get Started" else "Next", fontWeight = FontWeight.SemiBold) }
    }
}

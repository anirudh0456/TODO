package com.todo.app
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

val listIcons = listOf(Icons.Outlined.Person, Icons.Outlined.School, Icons.Outlined.Work, Icons.Outlined.ShoppingCart,
    Icons.Outlined.Folder, Icons.Outlined.Home, Icons.Outlined.Favorite, Icons.Outlined.Star) // icons you can pick for a list

@Composable fun ListsScreen(tasks: List<Task>, vm: TaskVm, back: () -> Unit) {
    val lists by vm.lists.collectAsState()
    var name by remember { mutableStateOf("") }; var icon by remember { mutableIntStateOf(0) } // new-list form
    var editing by remember { mutableStateOf<Long?>(null) }; var rename by remember { mutableStateOf("") } // which list is being renamed
    val fc = TextFieldDefaults.colors(focusedContainerColor = Ink.Glass, unfocusedContainerColor = Ink.Glass,
        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Ink.Mint)
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().imePadding(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { TopBar("Lists", back) }
        item { Section("NEW LIST") {
            TextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, shape = CircleShape, placeholder = { Text("List name") }, colors = fc)
            Row { listIcons.forEachIndexed { i, ic -> IconButton({ icon = i }) { Icon(ic, null, tint = if (icon == i) Ink.Mint else Ink.Muted) } } }
            Pill("Create list") { vm.addList(name, icon); name = "" } } }
        items(lists, key = { it.id }) { l -> GlassCard(Modifier.fillMaxWidth().animateItem()) { Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(listIcons[l.icon.coerceIn(0, listIcons.lastIndex)], null, tint = Ink.Mint); Spacer(Modifier.width(12.dp))
            if (editing == l.id) { TextField(rename, { rename = it }, Modifier.weight(1f), singleLine = true, colors = fc); Pill("Save") { vm.renameList(l, rename); editing = null } }
            else Column(Modifier.weight(1f)) { Text(l.name, fontWeight = FontWeight.SemiBold)
                Text("${tasks.count { it.listId == l.id && !it.done }} open • ${tasks.count { it.listId == l.id && it.done }} done", fontSize = 12.sp, color = Ink.Muted) } // real counts
            if (editing != l.id) IconButton({ editing = l.id; rename = l.name }) { Icon(Icons.Outlined.Edit, "Rename", tint = Ink.Muted) }
            IconButton({ vm.removeList(l) }) { Icon(Icons.Outlined.Delete, "Delete list", tint = Ink.Muted) } } } } // tasks stay, just unassigned
    }
}

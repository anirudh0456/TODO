package com.todo.app
import android.Manifest
import android.app.ActivityManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import androidx.navigation.NavType
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // draw behind the status/nav bars
        Jakarta = loadJakarta(assets) // Plus Jakarta Sans if the font files are in assets/fonts
        if (Build.VERSION.SDK_INT >= 33) registerForActivityResult(ActivityResultContracts.RequestPermission()) {}.launch(Manifest.permission.POST_NOTIFICATIONS) // ask to show reminders
        setContent { TodoApp() }
    }
}

@Composable fun TodoApp(vm: TaskVm = viewModel(), app: AppVm = viewModel(), fvm: FocusVm = viewModel()) {
    val nav = rememberNavController()
    val tasks by vm.tasks.collectAsState(); val subs by vm.subs.collectAsState(); val p by app.prefs.collectAsState()
    val dark = when (p.theme()) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() } // Light / Dark / System
    SideEffect { Ink.dark = dark } // tell the colours which theme is on
    val canvas by animateColorAsState(Ink.Canvas, tween(400), label = "theme") // background fades between themes
    val ready = p !== EMPTY_PREFS; val start = remember(ready) { if (p[K_ONB] == 1) "home" else "onboard" } // wait for saved settings
    LaunchedEffect(Unit) { fvm.onSession = { vm.logSession(it) } } // save finished focus blocks
    var sheet by remember { mutableStateOf(false) } // quick-add sheet open?
    val ctx = LocalContext.current; val blur = remember { Build.VERSION.SDK_INT >= 31 && !ctx.getSystemService(ActivityManager::class.java).isLowRamDevice } // no blur work on weak phones
    val backdrop = rememberGraphicsLayer() // a recording of the screen content that the glass nav blurs
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Ink.Mint, background = Ink.Canvas, surface = Ink.Surface, onSurface = Ink.Text, onBackground = Ink.Text, surfaceVariant = Ink.Glass, onSurfaceVariant = Ink.Muted) else lightColorScheme(primary = Ink.Mint, background = Ink.Canvas, surface = Ink.Surface, onSurface = Ink.Text, onBackground = Ink.Text, surfaceVariant = Ink.Glass, onSurfaceVariant = Ink.Muted), typography = jakartaTypography()) {
        CompositionLocalProvider(LocalContentColor provides Ink.Text, LocalOpen provides { nav.navigate("task/$it") }, LocalGo provides { nav.navigate(it) }) { // default text colour follows the theme
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize().drawWithContent { if (blur) { backdrop.record { this@drawWithContent.drawContent() }; drawLayer(backdrop) } else drawContent() }.background(canvas)) { // screen content, recorded
                Canvas(Modifier.fillMaxSize()) { // soft mint glow behind everything so the glass has light to catch
                    drawRect(Brush.radialGradient(listOf(Ink.Mint.copy(.10f), androidx.compose.ui.graphics.Color.Transparent), Offset(size.width * .9f, size.height * .05f), size.width * .9f))
                    drawRect(Brush.radialGradient(listOf(Ink.Mint.copy(.06f), androidx.compose.ui.graphics.Color.Transparent), Offset(size.width * .05f, size.height * .75f), size.width)) }
                if (ready) NavHost(nav, start, Modifier.fillMaxSize(), enterTransition = { fadeIn(tween(260)) + scaleIn(initialScale = .96f, animationSpec = spring(Spring.DampingRatioLowBouncy, Spring.StiffnessMediumLow)) }, exitTransition = { fadeOut(tween(140)) }) {
                    composable("home") { HomeScreen(tasks, vm) { nav.go("focus") } }
                    composable("upcoming") { UpcomingScreen(tasks, vm) }
                    composable("tasks") { TasksScreen(tasks, vm) }
                    composable("focus") { FocusScreen(tasks, vm, fvm, p) }
                    composable("onboard") { Onboarding { app.set(K_ONB, 1); nav.navigate("home") { popUpTo("onboard") { inclusive = true } } } }
                    composable("calendar") { CalendarScreen(tasks, vm) { nav.popBackStack() } }
                    composable("lists") { ListsScreen(tasks, vm) { nav.popBackStack() } }
                    composable("stats") { StatsScreen(tasks, vm) { nav.popBackStack() } }
                    composable("task/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { // details / edit
                        DetailScreen(it.arguments?.getLong("id") ?: 0L, tasks, subs, vm) { nav.popBackStack() } }
                    composable("settings") { SettingsScreen(app, p) }
                }
                }
                CompositionLocalProvider(LocalBackdrop provides (if (blur) backdrop else null)) { if (ready && route in listOf("home", "upcoming", "tasks", "focus", "settings")) GlassNav(route, Modifier.align(Alignment.BottomCenter)) { nav.go(it) } } // hidden while editing
                if (ready && route in listOf("home", "upcoming", "tasks")) AddFab({ sheet = true }, Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = 104.dp).navigationBarsPadding())
                if (sheet) QuickAddSheet(vm) { sheet = false }
            }
        }
    }
}

fun NavController.go(r: String) = navigate(r) { // switch tab but remember each tab's state
    popUpTo(graph.findStartDestination().id) { saveState = true }; launchSingleTop = true; restoreState = true }

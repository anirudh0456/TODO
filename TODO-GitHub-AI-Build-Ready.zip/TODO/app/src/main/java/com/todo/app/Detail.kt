package com.todo.app
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.*
import java.time.*
import java.time.format.DateTimeFormatter

val LocalOpen = staticCompositionLocalOf<(Long) -> Unit> { {} } // "open this task" action, set in TodoApp

@Composable fun Section(label: String, content: @Composable ColumnScope.() -> Unit) { // heading + glass card
    Label(label)
    GlassCard(Modifier.fillMaxWidth(), content = content)
}

@Composable fun DetailScreen(id: Long, tasks: List<Task>, subs: List<Sub>, vm: TaskVm, back: () -> Unit) {
    val t = tasks.firstOrNull { it.id == id }
    var title by remember(id) { mutableStateOf(t?.title ?: "") }; var notes by remember(id) { mutableStateOf(t?.notes ?: "") }
    var newSub by remember(id) { mutableStateOf("") }; val lists by vm.lists.collectAsState()
    if (t == null) { LaunchedEffect(Unit) { back() }; return } // task was deleted, so leave
    val today = LocalDate.now().toEpochDay()
    val upd = { x: Task -> vm.save(x.copy(title = title.ifBlank { t.title }, notes = notes)); Unit } // save, including the typed text
    BackHandler { upd(t); back() }
    fun at(h: Int, plus: Long) = LocalDate.now().plusDays(plus).atTime(h, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    val tonight = at(20, 0).let { if (it > System.currentTimeMillis()) it else at(20, 1) } // 8 PM, or tomorrow if it's past
    val fc = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, cursorColor = Ink.Mint)
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().imePadding(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Row(verticalAlignment = Alignment.CenterVertically) { IconButton({ upd(t); back() }) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Ink.Text) }; Title("Task") } }
        item { Section("TITLE") { TextField(title, { title = it }, Modifier.fillMaxWidth(), colors = fc) } }
        item { Section("NOTES") { TextField(notes, { notes = it }, Modifier.fillMaxWidth(), minLines = 3, placeholder = { Text("Add notes…") }, colors = fc) } }
        item { Section("PRIORITY") { Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
            prioNames.forEachIndexed { i, n -> Pill(n, t.priority == i) { upd(t.copy(priority = i)) } } } } }
        item { Section("DUE") { Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
            Pill("No date", t.dueDay == null) { upd(t.copy(dueDay = null)) }; Pill("Today", t.dueDay == today) { upd(t.copy(dueDay = today)) }
            Pill("Tomorrow", t.dueDay == today + 1) { upd(t.copy(dueDay = today + 1)) }; Pill("Next week", t.dueDay == today + 7) { upd(t.copy(dueDay = today + 7)) } } } }
        item { Section("REPEAT") { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Never", "Daily", "Weekly").forEachIndexed { i, n -> Pill(n, t.repeatMode == i) { upd(t.copy(repeatMode = i)) } } } } }
        item { Section("REMINDER") {
            Text(t.remindAt?.let { Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("EEE, MMM d h:mm a")) } ?: "Off", color = Ink.Muted)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
                Pill("None", t.remindAt == null) { upd(t.copy(remindAt = null)) }
                Pill("In 1 hour") { upd(t.copy(remindAt = System.currentTimeMillis() + 3_600_000L)) }
                Pill("Tonight 8 PM") { upd(t.copy(remindAt = tonight)) }; Pill("Tomorrow 9 AM") { upd(t.copy(remindAt = at(9, 1))) } } } }
        item { Section("LIST") { Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(8.dp)) {
            Pill("None", t.listId == null) { upd(t.copy(listId = null)) }; lists.forEach { l -> Pill(l.name, t.listId == l.id) { upd(t.copy(listId = l.id)) } } } } }
        item { Section("SUBTASKS") {
            subs.filter { it.taskId == id }.forEach { s -> Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Check(s.done) { vm.toggleSub(s) }
                Text(s.title, Modifier.weight(1f), color = if (s.done) Ink.Muted.copy(.5f) else Ink.Text, textDecoration = if (s.done) TextDecoration.LineThrough else null)
                IconButton({ vm.removeSub(s) }) { Icon(Icons.Outlined.Close, "Remove", tint = Ink.Muted) } } }
            TextField(newSub, { newSub = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Add subtask…") }, colors = fc,
                trailingIcon = { IconButton({ vm.addSub(id, newSub); newSub = "" }) { Icon(Icons.Outlined.Add, "Add", tint = Ink.Mint) } }) } }
        item { Pill("Delete task") { vm.remove(t) } } // screen closes itself once the task is gone
    }
}

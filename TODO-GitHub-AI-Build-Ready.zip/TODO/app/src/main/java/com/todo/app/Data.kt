package com.todo.app
import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.compose.runtime.Stable
import androidx.room.*
import java.time.LocalDate
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@Entity(tableName = "tasks") // one row in the "tasks" table = one task
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0, // database fills this in
    val title: String,
    val category: String = "Personal",
    val done: Boolean = false, // ticked or not
    val dueDay: Long? = null, // due date as a day number (epoch day); null = no date
    @ColumnInfo(defaultValue = "1") val priority: Int = 1, // 0 Low, 1 Medium, 2 High, 3 Urgent
    @ColumnInfo(defaultValue = "''") val notes: String = "", // free-text notes
    @ColumnInfo(defaultValue = "0") val repeatMode: Int = 0, // 0 never, 1 daily, 2 weekly
    val remindAt: Long? = null, // reminder time in milliseconds; null = none
    val completedAt: Long? = null, // when it was ticked off (feeds analytics)
    val listId: Long? = null, // which custom list it belongs to
)

@Entity(tableName = "subtasks") // a small step inside a task
data class Sub(@PrimaryKey(autoGenerate = true) val id: Long = 0, val taskId: Long, val title: String, val done: Boolean = false)

@Entity(tableName = "lists") // a custom list such as Work or Shopping
data class TaskList(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val icon: Int)

@Entity(tableName = "focus_sessions") // one finished focus block
data class FocusSession(@PrimaryKey(autoGenerate = true) val id: Long = 0, val finishedAt: Long, val minutes: Int)

@Dao // the list of things we can ask the database
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY done, id DESC") fun all(): Flow<List<Task>> // open tasks first; updates live
    @Insert suspend fun add(t: Task)
    @Insert suspend fun insert(t: Task): Long // like add, but hands back the new id
    @Query("SELECT * FROM lists ORDER BY id") fun lists(): Flow<List<TaskList>>
    @Insert suspend fun addList(l: TaskList)
    @Update suspend fun updateList(l: TaskList)
    @Delete suspend fun deleteList(l: TaskList)
    @Query("UPDATE tasks SET listId = NULL WHERE listId = :id") suspend fun unassign(id: Long) // deleting a list keeps its tasks
    @Query("SELECT * FROM focus_sessions ORDER BY finishedAt DESC") fun sessions(): Flow<List<FocusSession>>
    @Insert suspend fun addSession(s: FocusSession)
    @Query("SELECT * FROM subtasks") fun subs(): Flow<List<Sub>>
    @Insert suspend fun addSub(s: Sub)
    @Update suspend fun updateSub(s: Sub)
    @Delete suspend fun deleteSub(s: Sub)
    @Query("DELETE FROM subtasks WHERE taskId = :id") suspend fun clearSubs(id: Long)
    @Update suspend fun update(t: Task)
    @Delete suspend fun delete(t: Task)
}

@Database(
    entities = [Task::class, Sub::class, TaskList::class, FocusSession::class],
    version = 4,
    exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): TaskDao

    companion object {
        fun build(context: Context): AppDb {
            return Room.databaseBuilder(context, AppDb::class.java, "todo.db")
                .addMigrations(M1_2, M2_3, M3_4)
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        seed(db)
                    }
                })
                .build()
        }
    }
}

@Stable class TaskVm(app: Application) : AndroidViewModel(app) { // holds data for the screens
    private val dao = AppDb.build(app).dao()
    private val ctx: Context = app
    val subs = dao.subs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val lists = dao.lists().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sessions = dao.sessions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun logSession(m: Int) { viewModelScope.launch { dao.addSession(FocusSession(finishedAt = System.currentTimeMillis(), minutes = m)) } } // real history
    fun addList(n: String, i: Int) { if (n.isNotBlank()) viewModelScope.launch { dao.addList(TaskList(name = n.trim(), icon = i)) } }
    fun renameList(l: TaskList, n: String) { if (n.isNotBlank()) viewModelScope.launch { dao.updateList(l.copy(name = n.trim())) } }
    fun removeList(l: TaskList) = viewModelScope.launch { dao.unassign(l.id); dao.deleteList(l) }
    init { viewModelScope.launch { dao.all().first().forEach { Reminders.set(ctx, it) } } } // re-arm reminders each launch (covers reboots)
    val tasks = dao.all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun add(title: String, dueDay: Long? = null, priority: Int = 1, listId: Long? = null) { if (title.isNotBlank()) viewModelScope.launch { dao.add(Task(title = title.trim(), dueDay = dueDay, priority = priority, listId = listId)) } }
    fun toggle(t: Task) = viewModelScope.launch { // tick / untick
        dao.update(t.copy(done = !t.done, completedAt = if (t.done) null else System.currentTimeMillis()))
        if (t.done) { Reminders.set(ctx, t.copy(done = false)); return@launch } // un-ticked: reminder comes back
        Reminders.cancel(ctx, t.id)
        if (t.repeatMode > 0) { // repeating task: make the next copy
            val d = if (t.repeatMode == 1) 1 else 7; val day = 86_400_000L
            var r = t.remindAt?.plus(d * day); while (r != null && r <= System.currentTimeMillis()) r += d * day
            val n = t.copy(id = 0, done = false, completedAt = null, dueDay = (t.dueDay ?: LocalDate.now().toEpochDay()) + d, remindAt = r)
            Reminders.set(ctx, n.copy(id = dao.insert(n)))
        }
    }
    fun save(t: Task) = viewModelScope.launch { dao.update(t); Reminders.set(ctx, t) } // edit screen saves here
    fun remove(t: Task) = viewModelScope.launch { Reminders.cancel(ctx, t.id); dao.clearSubs(t.id); dao.delete(t) }
    fun addSub(id: Long, title: String) { if (title.isNotBlank()) viewModelScope.launch { dao.addSub(Sub(taskId = id, title = title.trim())) } }
    fun toggleSub(s: Sub) = viewModelScope.launch { dao.updateSub(s.copy(done = !s.done)) }
    fun removeSub(s: Sub) = viewModelScope.launch { dao.deleteSub(s) }
}

val M1_2 = object : Migration(1, 2) { // upgrades Stage 1 phones without deleting tasks
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE tasks ADD COLUMN dueDay INTEGER")
        db.execSQL("ALTER TABLE tasks ADD COLUMN priority INTEGER NOT NULL DEFAULT 1")
    }
}

val M2_3 = object : Migration(2, 3) { // keeps every existing task
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE tasks ADD COLUMN notes TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE tasks ADD COLUMN repeatMode INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE tasks ADD COLUMN remindAt INTEGER")
        db.execSQL("CREATE TABLE IF NOT EXISTS subtasks (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, taskId INTEGER NOT NULL, title TEXT NOT NULL, done INTEGER NOT NULL)")
    }
}

fun seed(db: SupportSQLiteDatabase) = db.execSQL("INSERT INTO lists (name, icon) VALUES ('Personal',0),('College',1),('Work',2),('Shopping',3),('Projects',4)")
val M3_4 = object : Migration(3, 4) { // keeps every task, adds dates for analytics, lists and focus history
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE tasks ADD COLUMN completedAt INTEGER")
        db.execSQL("ALTER TABLE tasks ADD COLUMN listId INTEGER")
        db.execSQL("CREATE TABLE IF NOT EXISTS lists (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, icon INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS focus_sessions (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, finishedAt INTEGER NOT NULL, minutes INTEGER NOT NULL)")
        seed(db)
    }
}

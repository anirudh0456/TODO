plugins {
    id("com.android.application"); id("org.jetbrains.kotlin.android"); id("com.google.devtools.ksp")
}
android {
    namespace = "com.todo.app" // code package
    compileSdk = 34
    defaultConfig {
        applicationId = "com.todo.app" // the app's unique ID
        minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = true; isShrinkResources = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt")) } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true } // turn on Jetpack Compose
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00")) // keeps Compose versions matching
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.room:room-runtime:2.6.1"); implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")
    implementation("androidx.datastore:datastore-preferences:1.1.1") // saves settings
}

// Fetches Plus Jakarta Sans (open font) on the first build if it is not already in assets/fonts.
val fontFile = layout.projectDirectory.file("src/main/assets/fonts/PlusJakartaSans.ttf").asFile
tasks.register("downloadFonts") {
    onlyIf { !fontFile.exists() }
    doLast {
        try {
            fontFile.parentFile.mkdirs()
            (java.net.URL("https://github.com/google/fonts/raw/main/ofl/plusjakartasans/PlusJakartaSans%5Bwght%5D.ttf").openConnection() as java.net.HttpURLConnection).apply { connectTimeout = 5000; readTimeout = 15000 }.inputStream.use { input -> fontFile.outputStream().use { input.copyTo(it) } }
        } catch (e: Exception) { fontFile.delete(); logger.warn("Could not download Plus Jakarta Sans (${e.message}). The app will use the system font.") }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn("downloadFonts") }

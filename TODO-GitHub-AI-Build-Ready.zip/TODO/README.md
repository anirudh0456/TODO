# TODO (com.todo.app) - Premium design pass

## Build
1. Android Studio Koala or newer (JDK 17). File > Open > this folder. Gradle sync needs internet.
2. First build tries to fetch Plus Jakarta Sans into app/src/main/assets/fonts (5 s timeout; if offline the app uses the system font).
3. Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk (Android 8.0+).
4. Command line: ./gradlew assembleDebug (needs local.properties with sdk.dir).

NOT compiled, run or screenshotted by the author (no Android SDK / internet in the build sandbox). Room DB v4; migrations 1->2, 2->3, 3->4 unchanged.

## Highest compile risk
Backdrop.kt (Compose 1.7 GraphicsLayer API from memory). If it errors, make backdropBlur() return `this`.

## This pass
New "Swift tick" icon (adaptive + monochrome + legacy PNGs, preview in branding/). Design tokens: ivory/white/deep-text light theme, graphite dark theme, calmer mint. Rows: quiet meta line with icons, High/Urgent priority dot. One section-label style. Haptics on tick and tab change. Notification icon. Window background matches theme (no white flash in dark mode).

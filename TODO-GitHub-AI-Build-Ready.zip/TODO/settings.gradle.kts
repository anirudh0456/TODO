pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } } // where Gradle finds plugins
dependencyResolutionManagement { repositories { google(); mavenCentral() } } // where it finds libraries
rootProject.name = "TODO" // project name
include(":app") // the one module
